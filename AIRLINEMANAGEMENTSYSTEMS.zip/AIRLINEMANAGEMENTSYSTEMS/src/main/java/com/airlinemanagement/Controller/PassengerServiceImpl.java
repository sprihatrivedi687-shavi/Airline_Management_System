package com.airlinemanagement.Controller;

import com.airlinemanagement.Model.PassengerModel;

import java.util.List;

public class PassengerServiceImpl {
    public void addPassenger(PassengerModel passenger) {

    }

    public List<PassengerModel> getAllPassengers() {
        return null;
    }

    public PassengerModel getPassengerById(int id) {
        return null;
    }
}
