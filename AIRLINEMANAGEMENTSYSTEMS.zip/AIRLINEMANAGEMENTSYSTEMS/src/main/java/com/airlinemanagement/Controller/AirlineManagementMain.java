package com.airlinemanagement.Controller;
import com.airlinemanagement.Model.*;
import com.airlinemanagement.Service.IMPL.*;

import java.util.List;
import java.util.Scanner;

public class AirlineManagementMain {

        public static void main(String[] args) {

            // Service layer instances1

            UsersServiceImpl usersService = new UsersServiceImpl();
            FlightsServiceImpl flightsService = new FlightsServiceImpl();
            PassengerServiceImpl passengerService = new PassengerServiceImpl();
            BookingServiceImpl bookingsService = new BookingServiceImpl();
            PaymentsServiceImpl paymentsService = new PaymentsServiceImpl();
            CancellationServiceImpl cancellationService = new CancellationServiceImpl();

            Scanner sc = new Scanner(System.in);
            int choice;

            do {
                System.out.println("\n=== AIRLINE MANAGEMENT SYSTEM ===");
                System.out.println("1. Manage Users");
                System.out.println("2. Manage Flights");
                System.out.println("3. Manage Passengers");
                System.out.println("4. Bookings");
                System.out.println("5. Payments");
                System.out.println("6. Cancellations");
                System.out.println("0. Exit");
                System.out.print("Enter choice: ");
                choice = sc.nextInt();
                sc.nextLine(); // consume newline

                switch (choice) {

                    case 1 -> manageUsers(sc, usersService);
                    case 2 -> manageFlights(sc, flightsService);
                    case 3 -> managePassengers(sc, passengerService);
                    case 4 -> manageBookings(sc, bookingsService);
                    case 5 -> managePayments(sc, paymentsService);
                    case 6 -> manageCancellations(sc, cancellationService);
                    case 0 -> System.out.println("Exiting... Thank you!");
                    default -> System.out.println("Invalid choice! Try again.");
                }

            } while (choice != 0);

            sc.close();
        }

        // ------------------- USERS -------------------
        private static void manageUsers(Scanner sc, UsersServiceImpl service) {
            System.out.println("\n--- User Management ---");
            System.out.println("1. Add User");
            System.out.println("2. View All Users");
            System.out.println("3. Search User by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter username: ");
                    String username = sc.nextLine();
                    System.out.print("Enter password: ");
                    String password = sc.nextLine();
                    System.out.print("Enter role: ");
                    String role = sc.nextLine();
                    UsersModel user = new UsersModel(username, password, role);
                    service.addUser(user);
                    System.out.println("User added successfully!");
                }
                case 2 -> {
                    List<UsersModel> users = service.getAllUsers();
                    users.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter User ID: ");
                    int id = sc.nextInt();
                    UsersModel user = service.getUserById(id);
                    System.out.println(user != null ? user : "User not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }

        // ------------------- FLIGHTS -------------------
        private static void manageFlights(Scanner sc, FlightsServiceImpl service) {
            System.out.println("\n--- Flight Management ---");
            System.out.println("1. Add Flight");
            System.out.println("2. View All Flights");
            System.out.println("3. Search Flight by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Flight Name: ");
                    String name = sc.nextLine();
                    System.out.print("Source: ");
                    String src = sc.nextLine();
                    System.out.print("Destination: ");
                    String dest = sc.nextLine();
                    System.out.print("Departure Time: ");
                    String dep = sc.nextLine();
                    System.out.print("Arrival Time: ");
                    String arr = sc.nextLine();
                    System.out.print("Total Seats: ");
                    int totalSeats = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Available Seats: ");
                    int availSeats = sc.nextInt();
                    sc.nextLine();

                    FlightsModel flight = new FlightsModel(name, src, dest, dep, arr, totalSeats, availSeats);
                    service.addFlights(flight);
                    System.out.println("Flight added successfully!");
                }
                case 2 -> {
                    List<FlightsModel> flights = service.getAllFlights();
                    flights.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Flight ID: ");
                    int id = sc.nextInt();
                    FlightsModel flight = service.getFlightById(id);
                    System.out.println(flight != null ? flight : "Flight not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }

        // ------------------- PASSENGERS -------------------
        private static void managePassengers(Scanner sc, PassengerServiceImpl service) {
            System.out.println("\n--- Passenger Management ---");
            System.out.println("1. Add Passenger");
            System.out.println("2. View All Passengers");
            System.out.println("3. Search Passenger by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Gender: ");
                    String gender = sc.nextLine();
                    System.out.print("Contact: ");
                    String contact = sc.nextLine();
                    System.out.print("Gmail: ");
                    String gmail = sc.nextLine();

                    PassengerModel passenger = new PassengerModel(name, age, gender, contact, gmail);
                    service.addPassenger(passenger);
                    System.out.println("Passenger added successfully!");
                }
                case 2 -> {
                    List<PassengerModel> passengers = service.getAllPassengers();
                    passengers.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Passenger ID: ");
                    int id = sc.nextInt();
                    PassengerModel passenger = service.getPassengerById(id);
                    System.out.println(passenger != null ? passenger : "Passenger not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }

        // ------------------- BOOKINGS -------------------
        private static void manageBookings(Scanner sc, BookingServiceImpl service) {
            System.out.println("\n--- Bookings ---");
            System.out.println("1. Add Booking");
            System.out.println("2. View All Bookings");
            System.out.println("3. Search Booking by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Flight ID: ");
                    int flightId = sc.nextInt();
                    System.out.print("Passenger ID: ");
                    int passengerId = sc.nextInt();
                    System.out.print("Seat No: ");
                    int seatNo = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Booking Date (YYYY-MM-DD): ");
                    String bookingDate = sc.nextLine();

                    BookingsModel booking = new BookingsModel(flightId, passengerId, seatNo, bookingDate);
                    service.addBooking(booking);
                    System.out.println("Booking added successfully!");
                }
                case 2 -> {
                    List<BookingsModel> bookings = service.getAllBookings();
                    bookings.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Booking ID: ");
                    int id = sc.nextInt();
                    BookingsModel booking = service.getBookingById(id);
                    System.out.println(booking != null ? booking : "Booking not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }

        // ------------------- PAYMENTS -------------------
        private static void managePayments(Scanner sc, PaymentsServiceImpl service) {
            System.out.println("\n--- Payments ---");
            System.out.println("1. Add Payment");
            System.out.println("2. View All Payments");
            System.out.println("3. Search Payment by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Booking ID: ");
                    int bookingId = sc.nextInt();
                    System.out.print("Amount: ");
                    double amount = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Payment Date (YYYY-MM-DD): ");
                    String paymentDate = sc.nextLine();
                    System.out.print("Payment Mode: ");
                    String paymentMode = sc.nextLine();
                    System.out.print("Status: ");
                    String status = sc.nextLine();

                    PaymentsModel payment = new PaymentsModel(bookingId, amount, paymentDate, paymentMode, status);
                    service.addPayment(payment);
                    System.out.println("Payment added successfully!");
                }
                case 2 -> {
                    List<PaymentsModel> payments = service.getAllPayments();
                    payments.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Payment ID: ");
                    int id = sc.nextInt();
                    PaymentsModel payment = service.getPaymentById(id);
                    System.out.println(payment != null ? payment : "Payment not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }

        // ------------------- CANCELLATIONS -------------------
        private static void manageCancellations(Scanner sc, CancellationServiceImpl service) {
            System.out.println("\n--- Cancellations ---");
            System.out.println("1. Add Cancellation");
            System.out.println("2. View All Cancellations");
            System.out.println("3. Search Cancellation by ID");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Booking ID: ");
                    int bookingId = sc.nextInt();
                    System.out.print("Flight ID: ");
                    int flightId = sc.nextInt();
                    System.out.print("Passenger ID: ");
                    int passengerId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Cancellation Time (YYYY-MM-DD): ");
                    String cancellationTime = sc.nextLine();
                    System.out.print("Refund Amount: ");
                    double refundAmount = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Cancellation Status: ");
                    String status = sc.nextLine();

                    CancellationModel cancellation = new CancellationModel(bookingId, flightId, passengerId, cancellationTime, refundAmount, status);
                    service.addCancellation(cancellation);
                    System.out.println("Cancellation added successfully!");
                }
                case 2 -> {
                    List<CancellationModel> cancellations = service.getAllCancellations();
                    cancellations.forEach(System.out::println);
                }
                case 3 -> {
                    System.out.print("Enter Cancellation ID: ");
                    int id = sc.nextInt();
                    CancellationModel cancellation = service.getCancellationById(id);
                    System.out.println(cancellation != null ? cancellation : "Cancellation not found!");
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }

