package com.airlinemanagement.Model;

public class CancellationModel {

        private int cancellation_id;
        private int booking_id;
        private int flight_id;
        private int passenger_id;
        private String cancellation_time;
        private double refund_amount;
        private String cancellation_status;

        // 🔹 No-argument constructor
        public CancellationModel() {
        }

        // 🔹 Constructor without cancellation_id (for insert operations)
        public CancellationModel(int booking_id, int flight_id, int passenger_id,
                            String cancellation_time, double refund_amount,
                            String cancellation_status) {

            this.booking_id = booking_id;
            this.flight_id = flight_id;
            this.passenger_id = passenger_id;
            this.cancellation_time = cancellation_time;
            this.refund_amount = refund_amount;
            this.cancellation_status = cancellation_status;
        }

        // 🔹 Constructor with cancellation_id (for fetch operations)
        public CancellationModel(int cancellation_id, int booking_id, int flight_id,
                            int passenger_id, String cancellation_time,
                            double refund_amount, String cancellation_status) {

            this.cancellation_id = cancellation_id;
            this.booking_id = booking_id;
            this.flight_id = flight_id;
            this.passenger_id = passenger_id;
            this.cancellation_time = cancellation_time;
            this.refund_amount = refund_amount;
            this.cancellation_status = cancellation_status;
        }

        // 🔹 Getters & Setters

        public int getCancellation_id() {
            return cancellation_id;
        }

        public void setCancellation_id(int cancellation_id) {
            this.cancellation_id = cancellation_id;
        }

        public int getBooking_id() {
            return booking_id;
        }

        public void setBooking_id(int booking_id) {
            this.booking_id = booking_id;
        }

        public int getFlight_id() {
            return flight_id;
        }

        public void setFlight_id(int flight_id) {
            this.flight_id = flight_id;
        }

        public int getPassenger_id() {
            return passenger_id;
        }

        public void setPassenger_id(int passenger_id) {
            this.passenger_id = passenger_id;
        }

        public String getCancellation_time() {
            return cancellation_time;
        }

        public void setCancellation_time(String cancellation_time) {
            this.cancellation_time = cancellation_time;
        }

        public double getRefund_amount() {
            return refund_amount;
        }

        public void setRefund_amount(double refund_amount) {
            this.refund_amount = refund_amount;
        }

        public String getCancellation_status() {
            return cancellation_status;
        }

        public void setCancellation_status(String cancellation_status) {
            this.cancellation_status = cancellation_status;
        }

        // 🔹 toString() method (optional)
        @Override
        public String toString() {
            return "Cancellation ID: " + cancellation_id +
                    ", Booking ID: " + booking_id +
                    ", Flight ID: " + flight_id +
                    ", Passenger ID: " + passenger_id +
                    ", Cancellation Time: " + cancellation_time +
                    ", Refund Amount: " + refund_amount +
                    ", Status: " + cancellation_status;
        }
    }

