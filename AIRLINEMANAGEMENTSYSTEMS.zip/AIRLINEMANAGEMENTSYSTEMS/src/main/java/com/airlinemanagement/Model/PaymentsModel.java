package com.airlinemanagement.Model;

public class PaymentsModel {

        private int payment_id;
        private int booking_id;
        private double amount;
        private String payment_date;
        private String payment_mode;
        private String status;

        // 🔹 No-argument constructor
        public PaymentsModel() {
        }

        // 🔹 Constructor without payment_id (for INSERT)
        public PaymentsModel(int booking_id, double amount,
                             String payment_date, String payment_mode,
                             String status) {

            this.booking_id = booking_id;
            this.amount = amount;
            this.payment_date = payment_date;
            this.payment_mode = payment_mode;
            this.status = status;
        }

        // 🔹 Constructor with payment_id (for FETCH)
        public PaymentsModel(int payment_id, int booking_id,
                             double amount, String payment_date,
                             String payment_mode, String status) {

            this.payment_id = payment_id;
            this.booking_id = booking_id;
            this.amount = amount;
            this.payment_date = payment_date;
            this.payment_mode = payment_mode;
            this.status = status;
        }

        // 🔹 Getters & Setters

        public int getPayment_id() {
            return payment_id;
        }

        public void setPayment_id(int payment_id) {
            this.payment_id = payment_id;
        }

        public int getBooking_id() {
            return booking_id;
        }

        public void setBooking_id(int booking_id) {
            this.booking_id = booking_id;
        }

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public String getPayment_date() {
            return payment_date;
        }

        public void setPayment_date(String payment_date) {
            this.payment_date = payment_date;
        }

        public String getPayment_mode() {
            return payment_mode;
        }

        public void setPayment_mode(String payment_mode) {
            this.payment_mode = payment_mode;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
