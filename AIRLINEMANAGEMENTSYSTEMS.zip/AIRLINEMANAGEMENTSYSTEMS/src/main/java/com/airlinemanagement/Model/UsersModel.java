package com.airlinemanagement.Model;

public class UsersModel {
    private int user_Id;
        private String username;
        private String password;
        private String role;   // ADMIN or PASSENGER

        // 🔹 No-argument constructor
        public UsersModel() {
        }

        // 🔹 Constructor without ID (for registration)
        public UsersModel(String username, String password, String role) {
            this.username = username;
            this.password = password;
            this.role = role;
        }

        // 🔹 Constructor with ID (for fetching from DB)
        public UsersModel(int userId, String username, String password, String role) {
            this.user_Id = userId;
            this.username = username;
            this.password = password;
            this.role = role;
        }

        // 🔹 Getters & Setters
        public int getUserId() {
            return user_Id;
        }

        public void setUserId(int userId) {
            this.user_Id = userId;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        // 🔹 Display method (optional)
        @Override
        public String toString() {
            return "User ID: " + user_Id +
                    ", Username: " + username +
                    ", Role: " + role;
        }
    }

