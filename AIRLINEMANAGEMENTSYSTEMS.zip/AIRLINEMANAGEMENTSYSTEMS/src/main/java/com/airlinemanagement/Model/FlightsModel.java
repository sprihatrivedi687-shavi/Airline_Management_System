package com.airlinemanagement.Model;

public class FlightsModel {

        private int flight_Id;
        private String flight_Name;
        private String source;
        private String destination;
        private String arrival_Time;
        private String departure_Time;
        private int total_Seats;
        private int available_Seats;

        // 🔹 No-argument constructor
        public FlightsModel() {
        }

        // 🔹 Constructor without flightId (for inserting new flight)
        public FlightsModel(String flightName, String source, String destination,
                       String arrivalTime, String departureTime,
                       int totalSeats, int availableSeats) {

            this.flight_Name = flightName;
            this.source = source;
            this.destination = destination;
            this.arrival_Time = arrivalTime;
            this.departure_Time = departureTime;
            this.total_Seats = totalSeats;
            this.available_Seats = availableSeats;
        }

        // 🔹 Constructor with flightId (for fetching from database)
        public FlightsModel(int flightId, String flightName, String source,
                       String destination, String arrivalTime,
                       String departureTime, int totalSeats, int availableSeats) {

            this.flight_Id = flightId;
            this.flight_Name = flightName;
            this.source = source;
            this.destination = destination;
            this.arrival_Time = arrivalTime;
            this.departure_Time = departureTime;
            this.total_Seats = totalSeats;
            this.available_Seats = availableSeats;
        }

        // 🔹 Getters & Setters

        public int getFlightId() {
            return flight_Id;
        }

        public void setFlightId(int flightId) {
            this.flight_Id = flightId;
        }

        public String getFlightName() {
            return flight_Name;
        }

        public void setFlightName(String flightName) {
            this.flight_Name = flightName;
        }

        public String getSource() {
            return source;
        }

        public void setSource(String source) {
            this.source = source;
        }

        public String getDestination() {
            return destination;
        }

        public void setDestination(String destination) {
            this.destination = destination;
        }

        public String getArrivalTime() {
            return arrival_Time;
        }

        public void setArrivalTime(String arrivalTime) {
            this.arrival_Time = arrivalTime;
        }

        public String getDepartureTime() {
            return departure_Time;
        }

        public void setDepartureTime(String departureTime) {
            this.departure_Time = departureTime;
        }

        public int getTotalSeats() {
            return total_Seats;
        }

        public void setTotalSeats(int totalSeats) {
            this.total_Seats = totalSeats;
        }

        public int getAvailableSeats() {
            return available_Seats;
        }

        public void setAvailableSeats(int availableSeats) {
            this.available_Seats = availableSeats;
        }

        // 🔹 toString() method (optional but useful)
        @Override
        public String toString() {
            return "Flight ID: " + flight_Id +
                    ", Flight Name: " + flight_Name +
                    ", Route: " + source + " → " + destination +
                    ", Departure: " + departure_Time +
                    ", Arrival: " + arrival_Time +
                    ", Seats Available: " + available_Seats;
        }
    }

