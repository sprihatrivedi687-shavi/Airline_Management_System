package com.airlinemanagement.Model;

public class PassengerModel {

        private int passenger_Id;
        private String name;
        private int age;
        private String gender;
        private String contact;
        private String gmail;

        // 🔹 No-argument constructor
        public PassengerModel() {
        }

        // 🔹 Constructor without passengerId (for inserting new passenger)
        public PassengerModel(String name, int age, String gender,
                         String contact, String gmail) {

            this.name = name;
            this.age = age;
            this.gender = gender;
            this.contact = contact;
            this.gmail = gmail;
        }

        // 🔹 Constructor with passengerId (for fetching from database)
        public PassengerModel(int passengerId, String name, int age,
                         String gender, String contact, String gmail) {

            this.passenger_Id = passengerId;
            this.name = name;
            this.age = age;
            this.gender = gender;
            this.contact = contact;
            this.gmail = gmail;
        }

        // 🔹 Getters & Setters

        public int getPassengerId() {
            return passenger_Id;
        }

        public void setPassengerId(int passengerId) {
            this.passenger_Id = passengerId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getContact() {
            return contact;
        }

        public void setContact(String contact) {
            this.contact = contact;
        }

        public String getGmail() {
            return gmail;
        }

        public void setGmail(String gmail) {
            this.gmail = gmail;
        }

        // 🔹 toString() method (optional)
        @Override
        public String toString() {
            return "Passenger ID: " + passenger_Id +
                    ", Name: " + name +
                    ", Age: " + age +
                    ", Gender: " + gender +
                    ", Contact: " + contact +
                    ", Gmail: " + gmail;
        }
    }

