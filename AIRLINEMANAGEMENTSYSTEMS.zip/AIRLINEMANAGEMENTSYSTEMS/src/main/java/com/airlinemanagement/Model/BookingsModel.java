package com.airlinemanagement.Model;

public class BookingsModel {

        private int bookings_id;
        private int flight_id;
        private int passenger_id;
        private int seat_no;
        private String booking_date;

        // 🔹 No-argument constructor
        public BookingsModel() {
        }

        // 🔹 Constructor without bookings_id (for insert operations)
        public BookingsModel(int flight_id, int passenger_id,
                        int seat_no, String booking_date) {

            this.flight_id = flight_id;
            this.passenger_id = passenger_id;
            this.seat_no = seat_no;
            this.booking_date = booking_date;
        }

        // 🔹 Constructor with bookings_id (for fetch operations)
        public BookingsModel(int bookings_id, int flight_id,
                        int passenger_id, int seat_no,
                        String booking_date) {

            this.bookings_id = bookings_id;
            this.flight_id = flight_id;
            this.passenger_id = passenger_id;
            this.seat_no = seat_no;
            this.booking_date = booking_date;
        }

        // 🔹 Getters & Setters

        public int getBookings_id() {
            return bookings_id;
        }

        public void setBookings_id(int bookings_id) {
            this.bookings_id = bookings_id;
        }

        public int getFlight_id() {
            return flight_id;
        }

        public void setFlight_id(int flight_id) {
            this.flight_id = flight_id;
        }

        public int getPassenger_id() {
            return passenger_id;
        }

        public void setPassenger_id(int passenger_id) {
            this.passenger_id = passenger_id;
        }

        public int getSeat_no() {
            return seat_no;
        }

        public void setSeat_no(int seat_no) {
            this.seat_no = seat_no;
        }

        public String getBooking_date() {
            return booking_date;
        }

        public void setBooking_date(String booking_date) {
            this.booking_date = booking_date;
        }

        // 🔹 toString() method (optional)
        @Override
        public String toString() {
            return "Bookings ID: " + bookings_id +
                    ", Flight ID: " + flight_id +
                    ", Passenger ID: " + passenger_id +
                    ", Seat No: " + seat_no +
                    ", Booking Date: " + booking_date;
        }
    }

