package com.airlinemanagement.util;

public class TestDB {
        public static void main(String[] args) {
            DBUtil.getConnection();
        }
    }

