package com.airlinemanagement.DAO.Impl;
import com.airlinemanagement.DAO.UsersDAO.UserDao;
import com.airlinemanagement.Model.UsersModel;
import com.airlinemanagement.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsersDAOImpl {
    public static class UserDAOImpl implements UserDao {

        @Override
        public void addUser(UsersModel user) {
            String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPassword());
                ps.setString(3, user.getRole());
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public UsersModel getUserById(int id) {
            UsersModel user = null;
            String sql = "SELECT * FROM users WHERE user_id=?";
            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    user = new UsersModel(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return user;
        }

        @Override
        public List<UsersModel> getAllUsers() {
            List<UsersModel> list = new ArrayList<>();
            String sql = "SELECT * FROM users";
            try (Connection con = DBUtil.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    UsersModel user = new UsersModel(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role")
                    );
                    list.add(user);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        @Override
        public void updateUserl(UsersModel user) {
            String sql = "UPDATE users SET username=?, password=?, role=? WHERE user_id=?";
            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPassword());
                ps.setString(3, user.getRole());
                ps.setInt(4, user.getUserId());
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void deleteUser(int id) {
            String sql = "DELETE FROM users WHERE user_id=?";
            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public UsersModel login(String username, String password) {
            UsersModel user = null;
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, username);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    user = new UsersModel(
                            rs.getInt("user_id"),
                            rs.getString("username"),
                            rs.getString("password"),
                            rs.getString("role")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return user;
        }
    }
}
