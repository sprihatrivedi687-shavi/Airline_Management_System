package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.FlightsModel;
import java.util.List;
public class FlightsDAO {
    public interface FlightsDao {

        // Add a new flight
        void addFlights(FlightsModel flight);

        // Get a flight by ID
        FlightsModel getFlightById(int id);

        // Get all flights
        List<FlightsModel> getAllFlights();

        // Update flight details
        void updateFlights(FlightsModel flight);

        // Delete flight by ID
        void deleteFlights(int id);
    }
}
