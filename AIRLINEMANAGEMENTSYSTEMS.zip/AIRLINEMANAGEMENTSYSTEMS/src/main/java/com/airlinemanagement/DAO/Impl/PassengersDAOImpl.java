package com.airlinemanagement.DAO.Impl;
import com.airlinemanagement.DAO.PassengersDAO;
import com.airlinemanagement.DAO.PassengersDAO.PassengerDao;
import com.airlinemanagement.Model.PassengerModel;
import com.airlinemanagement.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
    public class PassengersDAOImpl {
        public static class PassengerDAOImpl implements PassengerDao {

            @Override
            public void addPassenger(PassengerModel passenger) {
                String sql = "INSERT INTO passengers (name, age, gender, contact, gmail) VALUES (?, ?, ?, ?, ?)";
                try (Connection con = DBUtil.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setString(1, passenger.getName());
                    ps.setInt(2, passenger.getAge());
                    ps.setString(3, passenger.getGender());
                    ps.setString(4, passenger.getContact());
                    ps.setString(5, passenger.getGmail());
                    ps.executeUpdate();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public PassengerModel getPassengerById(int id) {
                PassengerModel passenger = null;
                String sql = "SELECT * FROM passengers WHERE passenger_id=?";
                try (Connection con = DBUtil.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setInt(1, id);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        passenger = new PassengerModel(
                                rs.getInt("passenger_id"),
                                rs.getString("name"),
                                rs.getInt("age"),
                                rs.getString("gender"),
                                rs.getString("contact"),
                                rs.getString("gmail")
                        );
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return passenger;
            }

            @Override
            public List<PassengerModel> getAllPassengers() {
                List<PassengerModel> list = new ArrayList<>();
                String sql = "SELECT * FROM passengers";
                try (Connection con = DBUtil.getConnection();
                     Statement st = con.createStatement();
                     ResultSet rs = st.executeQuery(sql)) {

                    while (rs.next()) {
                        PassengerModel passenger = new PassengerModel(
                                rs.getInt("passenger_id"),
                                rs.getString("name"),
                                rs.getInt("age"),
                                rs.getString("gender"),
                                rs.getString("contact"),
                                rs.getString("gmail")
                        );
                        list.add(passenger);
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return list;
            }

            @Override
            public void updatePassenger(PassengerModel passenger) {
                String sql = "UPDATE passengers SET name=?, age=?, gender=?, contact=?, gmail=? WHERE passenger_id=?";
                try (Connection con = DBUtil.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setString(1, passenger.getName());
                    ps.setInt(2, passenger.getAge());
                    ps.setString(3, passenger.getGender());
                    ps.setString(4, passenger.getContact());
                    ps.setString(5, passenger.getGmail());
                    ps.setInt(6, passenger.getPassengerId());
                    ps.executeUpdate();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void deletePassenger(int id) {
                String sql = "DELETE FROM passengers WHERE passenger_id=?";
                try (Connection con = DBUtil.getConnection();
                     PreparedStatement ps = con.prepareStatement(sql)) {

                    ps.setInt(1, id);
                    ps.executeUpdate();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }