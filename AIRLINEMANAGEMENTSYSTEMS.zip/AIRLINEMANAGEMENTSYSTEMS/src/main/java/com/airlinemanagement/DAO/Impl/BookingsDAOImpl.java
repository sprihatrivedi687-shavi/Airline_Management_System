package com.airlinemanagement.DAO.Impl;
import com.airlinemanagement.DAO.BookingsDAO.BookingDao;
import com.airlinemanagement.Model.BookingsModel;
import com.airlinemanagement.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class BookingsDAOImpl implements BookingDao {
    @Override
    public void addBooking(BookingsModel booking) {

    }

    @Override
    public BookingsModel getBookingById(int id) {
        return null;
    }

    @Override
    public List<BookingsModel> getAllBookings() {
        return List.of();
    }

    @Override
    public void updateBooking(BookingsModel booking) {

    }

    @Override
    public void deleteBooking(int id) {

    }

    public static class BookingDAOImpl implements BookingDao {

        @Override
        public void addBooking(BookingsModel booking) {
            String sql = "INSERT INTO bookings (flight_id, passenger_id, seat_no, booking_date) VALUES (?, ?, ?, ?)";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, booking.getFlight_id());
                ps.setInt(2, booking.getPassenger_id());
                ps.setInt(3, booking.getSeat_no());
                ps.setString(4, booking.getBooking_date());
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public BookingsModel getBookingById(int id) {
            BookingsModel booking = null;
            String sql = "SELECT * FROM bookings WHERE booking_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    booking = new BookingsModel(
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getInt("passenger_id"),
                            rs.getInt("seat_no"),
                            rs.getString("booking_date")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return booking;
        }

        @Override
        public List<BookingsModel> getAllBookings() {
            List<BookingsModel> list = new ArrayList<>();
            String sql = "SELECT * FROM bookings";

            try (Connection con = DBUtil.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    BookingsModel booking = new BookingsModel(
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getInt("passenger_id"),
                            rs.getInt("seat_no"),
                            rs.getString("booking_date")
                    );
                    list.add(booking);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        @Override
        public void updateBooking(BookingsModel booking) {
            String sql = "UPDATE bookings SET flight_id=?, passenger_id=?, seat_no=?, booking_date=? WHERE booking_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, booking.getFlight_id());
                ps.setInt(2, booking.getPassenger_id());
                ps.setInt(3, booking.getSeat_no());
                ps.setString(4, booking.getBooking_date());
                ps.setInt(5, booking.getBookings_id());
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void deleteBooking(int id) {
            String sql = "DELETE FROM bookings WHERE booking_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
