package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.BookingsModel;
import java.util.List;
public class BookingsDAO {
    public interface BookingDao {
        // Add a new booking
        void addBooking(BookingsModel booking);

        // Get a booking by ID
        BookingsModel getBookingById(int id);

        // Get all bookings
        List<BookingsModel> getAllBookings();

        // Update booking details
        void updateBooking(BookingsModel booking);

        // Delete booking by ID
        void deleteBooking(int id);
    }
}



