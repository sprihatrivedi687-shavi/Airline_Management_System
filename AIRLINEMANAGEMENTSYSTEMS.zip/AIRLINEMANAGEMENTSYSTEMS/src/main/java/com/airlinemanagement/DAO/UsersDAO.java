package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.UsersModel;

import java.util.List;
public class UsersDAO {
    public interface UserDao {

        // Add a new user
        void addUser(UsersModel user );

        // Get a user by ID
        UsersModel getUserById(int id);

        // Get all users
        List<UsersModel> getAllUsers();

        // Update existing user
        void updateUserl(UsersModel user);

        // Delete user by ID
        void deleteUser(int id);

        // Login (optional but useful)
        UsersModel login(String username, String password);
    }
}
