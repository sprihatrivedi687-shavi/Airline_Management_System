package com.airlinemanagement.DAO.Impl;

import com.airlinemanagement.DAO.CancellationDAO.CancellationDao;
import com.airlinemanagement.Model.CancellationModel;
import com.airlinemanagement.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class CancellationDAOImpl implements CancellationDao {

    @Override
    public void addCancellation(CancellationModel cancellation) {

    }

    @Override
    public CancellationModel getCancellationById(int id) {
        return null;
    }

    @Override
    public List<CancellationModel> getAllCancellations() {
        return List.of();
    }

    @Override
    public void updateCancellation(CancellationModel cancellation) {

    }

    public class CancellationsDAOImpl implements CancellationDao {

        @Override
        public void addCancellation(CancellationModel cancellation) {
            String sql = "INSERT INTO cancellations " +
                    "(booking_id, flight_id, passenger_id, cancellation_time, refund_amount, cancellation_status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, cancellation.getBooking_id());
                ps.setInt(2, cancellation.getFlight_id());
                ps.setInt(3, cancellation.getPassenger_id());
                ps.setString(4, cancellation.getCancellation_time());
                ps.setDouble(5, cancellation.getRefund_amount());
                ps.setString(6, cancellation.getCancellation_status());

                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public CancellationModel getCancellationById(int id) {
            CancellationModel cancellation = null;
            String sql = "SELECT * FROM cancellations WHERE cancellation_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    cancellation = new CancellationModel(
                            rs.getInt("cancellation_id"),
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getInt("passenger_id"),
                            rs.getString("cancellation_time"),
                            rs.getDouble("refund_amount"),
                            rs.getString("cancellation_status")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return cancellation;
        }

        @Override
        public List<CancellationModel> getAllCancellations() {
            List<CancellationModel> list = new ArrayList<>();
            String sql = "SELECT * FROM cancellations";

            try (Connection con = DBUtil.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    CancellationModel cancellation = new CancellationModel(
                            rs.getInt("cancellation_id"),
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getInt("passenger_id"),
                            rs.getString("cancellation_time"),
                            rs.getDouble("refund_amount"),
                            rs.getString("cancellation_status")
                    );
                    list.add(cancellation);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        @Override
        public void updateCancellation(CancellationModel cancellation) {
            String sql = "UPDATE cancellations SET " +
                    "booking_id=?, flight_id=?, passenger_id=?, " +
                    "cancellation_time=?, refund_amount=?, cancellation_status=? " +
                    "WHERE cancellation_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, cancellation.getBooking_id());
                ps.setInt(2, cancellation.getFlight_id());
                ps.setInt(3, cancellation.getPassenger_id());
                ps.setString(4, cancellation.getCancellation_time());
                ps.setDouble(5, cancellation.getRefund_amount());
                ps.setString(6, cancellation.getCancellation_status());
                ps.setInt(7, cancellation.getCancellation_id());

                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
