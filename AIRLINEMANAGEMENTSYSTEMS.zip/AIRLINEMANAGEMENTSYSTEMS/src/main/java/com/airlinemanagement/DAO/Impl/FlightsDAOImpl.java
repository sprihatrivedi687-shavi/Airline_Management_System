package com.airlinemanagement.DAO.Impl;
import com.airlinemanagement.DAO.FlightsDAO.FlightsDao;
import com.airlinemanagement.Model.FlightsModel;
import com.airlinemanagement.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightsDAOImpl implements FlightsDao {

    @Override
    public void addFlights(FlightsModel flight) {
        String sql = "INSERT INTO flights (flight_name, source, destination, departure_time, arrival_time, total_seats, available_seats) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, flight.getFlightName());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getTotalSeats());
            ps.setInt(7, flight.getAvailableSeats());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public FlightsModel getFlightById(int id) {
        FlightsModel flight = null;
        String sql = "SELECT * FROM flights WHERE flight_id=?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                flight = new FlightsModel(
                        rs.getInt("flight_id"),
                        rs.getString("flight_name"),
                        rs.getString("source"),
                        rs.getString("destination"),
                        rs.getString("departure_time"),
                        rs.getString("arrival_time"),
                        rs.getInt("total_seats"),
                        rs.getInt("available_seats")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flight;
    }

    @Override
    public List<FlightsModel> getAllFlights() {
        List<FlightsModel> list = new ArrayList<>();
        String sql = "SELECT * FROM flights";
        try (Connection con = DBUtil.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                FlightsModel flight = new FlightsModel(
                        rs.getInt("flight_id"),
                        rs.getString("flight_name"),
                        rs.getString("source"),
                        rs.getString("destination"),
                        rs.getString("departure_time"),
                        rs.getString("arrival_time"),
                        rs.getInt("total_seats"),
                        rs.getInt("available_seats")
                );
                list.add(flight);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public void updateFlights(FlightsModel flight) {
        String sql = "UPDATE flights SET flight_name=?, source=?, destination=?, departure_time=?, arrival_time=?, total_seats=?, available_seats=? WHERE flight_id=?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, flight.getFlightName());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getTotalSeats());
            ps.setInt(7, flight.getAvailableSeats());
            ps.setInt(8, flight.getFlightId());
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteFlights(int id) {
        String sql = "DELETE FROM flights WHERE flight_id=?";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


