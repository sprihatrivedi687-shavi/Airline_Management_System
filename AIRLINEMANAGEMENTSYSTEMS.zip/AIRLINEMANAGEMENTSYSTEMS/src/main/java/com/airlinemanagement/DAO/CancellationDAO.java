package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.CancellationModel;
import java.util.List;
public class CancellationDAO {
    public CancellationModel getCancellationById(int id) {
        return null;
    }

    public interface CancellationDao {

        // Add a new cancellation
        void addCancellation(CancellationModel cancellation);

        // Get a cancellation by ID
        CancellationModel getCancellationById(int id);

        // Get all cancellations
        List<CancellationModel> getAllCancellations();

        // Update cancellation details
        void updateCancellation(CancellationModel cancellation);
    }
}
