package com.airlinemanagement.DAO.Impl;
import com.airlinemanagement.DAO.PaymentsDAO.PaymentDao;
import com.airlinemanagement.Model.PaymentsModel;
import com.airlinemanagement.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class PaymentsDAOImpl implements PaymentDao {
    @Override
    public void addPayment(PaymentsModel payment) {

    }

    @Override
    public PaymentsModel getPaymentById(int id) {
        return null;
    }

    @Override
    public List<PaymentsModel> getAllPayments() {
        return List.of();
    }

    @Override
    public void updatePayment(PaymentsModel payment) {

    }

    @Override
    public void deletePayment(int id) {

    }

    public class PaymentDAOImpl implements PaymentDao {

        @Override
        public void addPayment(PaymentsModel payment) {
            String sql = "INSERT INTO payments (booking_id, amount, payment_date, payment_mode, status) VALUES (?, ?, ?, ?, ?)";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, payment.getBooking_id());
                ps.setDouble(2, payment.getAmount());
                ps.setString(3, payment.getPayment_date());
                ps.setString(4, payment.getPayment_mode());
                ps.setString(4, payment.getStatus());

                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public PaymentsModel getPaymentById(int id) {
            PaymentsModel payment = null;
            String sql = "SELECT * FROM payments WHERE payment_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    payment = new PaymentsModel(
                            rs.getInt("payment_id"),
                            rs.getInt("booking_id"),
                            rs.getDouble("amount"),
                            rs.getString("payment_date"),
                            rs.getString("payment_mode"),
                            rs.getString("status")
                    );
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return payment;
        }

        @Override
        public List<PaymentsModel> getAllPayments() {
            List<PaymentsModel> list = new ArrayList<>();
            String sql = "SELECT * FROM payments";

            try (Connection con = DBUtil.getConnection();
                 Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    PaymentsModel payment = new PaymentsModel(
                            rs.getInt("payment_id"),
                            rs.getInt("booking_id"),
                            rs.getDouble("amount"),
                            rs.getString("payment_date"),
                            rs.getString("payment_mode"),
                            rs.getString("status")
                    );
                    list.add(payment);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return list;
        }

        @Override
        public void updatePayment(PaymentsModel payment) {
            String sql = "UPDATE payments SET booking_id=?, amount=?, payment_date=?, payment_mode=?, status=? WHERE payment_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, payment.getBooking_id());
                ps.setDouble(2, payment.getAmount());
                ps.setString(3, payment.getPayment_date());
                ps.setString(4, payment.getPayment_mode());
                ps.setString(5, payment.getStatus());
                ps.setInt(6, payment.getPayment_id());
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void deletePayment(int id) {
            String sql = "DELETE FROM payments WHERE payment_id=?";

            try (Connection con = DBUtil.getConnection();
                 PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, id);
                ps.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
