package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.PassengerModel;
import java.util.List;
public  class PassengersDAO {
    public interface PassengerDao {
        // Add a new passenger
        void addPassenger(PassengerModel passenger);
        // Get a passenger by ID
        PassengerModel getPassengerById(int id);

        // Get all passengers
        List<PassengerModel> getAllPassengers();

        // Update passenger details
        void updatePassenger(PassengerModel passenger);

        // Delete passenger by ID
        void deletePassenger(int id);
    }
}
