package com.airlinemanagement.DAO;
import com.airlinemanagement.Model.PaymentsModel;
import java.util.List;

public class PaymentsDAO {
    public interface PaymentDao {

        // Add a new payment
        void addPayment(PaymentsModel payment);

        // Get a payment by ID
        PaymentsModel getPaymentById(int id);

        // Get all payments
        List<PaymentsModel> getAllPayments();

        // Update payment details
        void updatePayment(PaymentsModel payment);

        // Delete payment by ID
        void deletePayment(int id);
    }
}
