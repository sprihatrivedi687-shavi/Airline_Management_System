package com.airlinemanagement.Service.IMPL;
import com.airlinemanagement.DAO.PassengersDAO.PassengerDao;
import com.airlinemanagement.DAO.Impl.PassengersDAOImpl;
import com.airlinemanagement.Model.PassengerModel;
import com.airlinemanagement.Service.PassengerService.PassengersService;

import java.util.List;

    class PassengersServiceImpl implements PassengersService {

        // DAO instance
        private final PassengerDao passengerDao;

        // Constructor to initialize DAO
        public PassengersServiceImpl() {
            this.passengerDao = new PassengersDAOImpl.PassengerDAOImpl();
        }

        @Override
        public void addPassenger(PassengerModel passenger) {
            passengerDao.addPassenger(passenger);
        }

        @Override
        public PassengerModel getPassengerById(int id) {
            return passengerDao.getPassengerById(id);
        }

        @Override
        public List<PassengerModel> getAllPassengers() {
            return passengerDao.getAllPassengers();
        }

        @Override
        public void updatePassenger(PassengerModel passenger) {
            passengerDao.updatePassenger(passenger);
        }

        @Override
        public void deletePassenger(int id) {
            passengerDao.deletePassenger(id);
        }
    }

