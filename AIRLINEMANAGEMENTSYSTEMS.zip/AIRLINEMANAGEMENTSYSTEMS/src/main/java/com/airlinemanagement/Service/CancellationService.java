package com.airlinemanagement.Service;
import com.airlinemanagement.Model.CancellationModel;
import java.util.List;
public class CancellationService {
    public static interface CancellationsService {

        void addCancellation(CancellationModel cancellation);

        CancellationModel getCancellationById(int id);

        List<CancellationModel> getAllCancellations();

        void updateCancellation(CancellationModel cancellation);
    }
}
