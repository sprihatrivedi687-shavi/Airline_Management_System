package com.airlinemanagement.Service.IMPL;

import com.airlinemanagement.DAO.PaymentsDAO.PaymentDao;
import com.airlinemanagement.DAO.Impl.PaymentsDAOImpl;
import com.airlinemanagement.Model.PaymentsModel;
import com.airlinemanagement.Service.PaymentService.PaymentsService;

import java.util.List;

public class PaymentsServiceImpl implements PaymentsService {

    // DAO instance
    private final PaymentDao paymentDao;

    // Constructor to initialize DAO
    public PaymentsServiceImpl() {
        this.paymentDao = new PaymentsDAOImpl();
    }

    @Override
    public void addPayment(PaymentsModel payment) {
        paymentDao.addPayment(payment);
    }

    @Override
    public PaymentsModel getPaymentById(int id) {
        return paymentDao.getPaymentById(id);
    }

    @Override
    public List<PaymentsModel> getAllPayments() {
        return paymentDao.getAllPayments();
    }

    @Override
    public void updatePayment(PaymentsModel payment) {
        paymentDao.updatePayment(payment);
    }

    @Override
    public void deletePayment(int id) {
        paymentDao.deletePayment(id);
    }
}