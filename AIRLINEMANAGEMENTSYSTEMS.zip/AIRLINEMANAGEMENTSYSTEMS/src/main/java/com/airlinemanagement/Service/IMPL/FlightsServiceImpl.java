package com.airlinemanagement.Service.IMPL;
import com.airlinemanagement.DAO.FlightsDAO.FlightsDao;
import com.airlinemanagement.DAO.Impl.FlightsDAOImpl;
import com.airlinemanagement.Model.FlightsModel;
import com.airlinemanagement.Service.FlightsService.FlightService;

import java.util.List;

    public class FlightsServiceImpl implements FlightService {

        // DAO instance
        private final FlightsDao flightsDao;

        // Constructor to initialize DAO
        public FlightsServiceImpl() {
            this.flightsDao = new FlightsDAOImpl();
        }

        @Override
        public void addFlights(FlightsModel flight) {
            flightsDao.addFlights(flight);
        }

        @Override
        public FlightsModel getFlightById(int id) {
            return flightsDao.getFlightById(id);
        }

        @Override
        public List<FlightsModel> getAllFlights() {
            return flightsDao.getAllFlights();
        }

        @Override
        public void updateFlights(FlightsModel flight) {
            flightsDao.updateFlights(flight);
        }

        @Override
        public void deleteFlights(int id) {
            flightsDao.deleteFlights(id);
        }
    }

