package com.airlinemanagement.Service.IMPL;

import com.airlinemanagement.DAO.CancellationDAO.CancellationDao;
import com.airlinemanagement.DAO.Impl.CancellationDAOImpl;
import com.airlinemanagement.Model.CancellationModel;
import com.airlinemanagement.Service.CancellationService.CancellationsService;

import java.util.List;

public class CancellationServiceImpl implements CancellationsService {

    // DAO instance
    private final CancellationDao cancellationDao;

    // Constructor to initialize DAO
    public CancellationServiceImpl() {
        this.cancellationDao = new CancellationDAOImpl();
    }

    @Override
    public void addCancellation(CancellationModel cancellation) {
        cancellationDao.addCancellation(cancellation);
    }

    @Override
    public CancellationModel getCancellationById(int id) {
        return cancellationDao.getCancellationById(id);
    }

    @Override
    public List<CancellationModel> getAllCancellations() {
        return cancellationDao.getAllCancellations();
    }

    @Override
    public void updateCancellation(CancellationModel cancellation) {
        cancellationDao.updateCancellation(cancellation);
    }
}