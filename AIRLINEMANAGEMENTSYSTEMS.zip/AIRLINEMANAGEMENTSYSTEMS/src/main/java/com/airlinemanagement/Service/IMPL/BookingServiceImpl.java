package com.airlinemanagement.Service.IMPL;

import com.airlinemanagement.DAO.BookingsDAO.BookingDao;
import com.airlinemanagement.DAO.Impl.BookingsDAOImpl;
import com.airlinemanagement.Model.BookingsModel;
import com.airlinemanagement.Service.BookingsService.BookingService;

import java.util.List;

public class BookingServiceImpl implements BookingService {

    // DAO instance
    private final BookingDao bookingDao;

    // Constructor to initialize DAO
    public BookingServiceImpl() {
        this.bookingDao = new BookingsDAOImpl();
    }

    @Override
    public void addBooking(BookingsModel booking) {
        bookingDao.addBooking(booking);
    }

    @Override
    public BookingsModel getBookingById(int id) {
        return bookingDao.getBookingById(id);
    }

    @Override
    public List<BookingsModel> getAllBookings() {
        return bookingDao.getAllBookings();
    }

    @Override
    public void updateBooking(BookingsModel booking) {
        bookingDao.updateBooking(booking);
    }

    @Override
    public void deleteBooking(int id) {
        bookingDao.deleteBooking(id);
    }
}