package com.airlinemanagement.Service.IMPL;
import com.airlinemanagement.DAO.UsersDAO.UserDao;
import com.airlinemanagement.DAO.Impl.UsersDAOImpl;
import com.airlinemanagement.Model.UsersModel;
import com.airlinemanagement.Service.UsersService.UserService;

import java.util.List;
    public class UsersServiceImpl implements UserService {

        // DAO instance
        private final UserDao userDao = new UsersDAOImpl.UserDAOImpl() {
            @Override
            public void addUser(UsersModel user) {

            }

            @Override
            public UsersModel getUserById(int id) {
                return null;
            }

            @Override
            public List<UsersModel> getAllUsers() {
                return List.of();
            }

            @Override
            public void updateUserl(UsersModel user) {

            }

            @Override
            public void deleteUser(int id) {

            }

            @Override
            public UsersModel login(String username, String password) {
                return null;
            }
        };

        @Override
        public void addUser(UsersModel user) {
            userDao.addUser(user);
        }

        @Override
        public UsersModel getUserById(int id) {
            return userDao.getUserById(id);
        }

        @Override
        public List<UsersModel> getAllUsers() {
            return userDao.getAllUsers();
        }

        @Override
        public void updateUser(UsersModel user) {
            userDao.updateUserl(user);  // Matches DAO method name
        }

        @Override
        public void deleteUser(int id) {
            userDao.deleteUser(id);
        }

        @Override
        public UsersModel login(String username, String password) {
            return userDao.login(username, password);
        }

        private static class MyUserDao implements UserDao {
            @Override
            public void addUser(UsersModel user) {

            }

            @Override
            public UsersModel getUserById(int id) {
                return null;
            }

            @Override
            public List<UsersModel> getAllUsers() {
                return List.of();
            }

            @Override
            public void updateUserl(UsersModel user) {

            }

            @Override
            public void deleteUser(int id) {

            }

            @Override
            public UsersModel login(String username, String password) {
                return null;
            }
        }
    }
