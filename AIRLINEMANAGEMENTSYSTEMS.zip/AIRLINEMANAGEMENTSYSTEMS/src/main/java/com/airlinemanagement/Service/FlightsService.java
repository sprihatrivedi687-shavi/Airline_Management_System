package com.airlinemanagement.Service;
import com.airlinemanagement.Model.FlightsModel;
import java.util.List;
public abstract class FlightsService {
    public abstract void addFlight(FlightsModel flight);

    public abstract FlightsModel getFlightById(int id);

    public abstract List<FlightsModel> getAllFlights();

    public abstract void updateFlight(FlightsModel flight);

    public abstract void deleteFlight(int id);

    public interface FlightService {

        void addFlights(FlightsModel flight);

        FlightsModel getFlightById(int id);

        List<FlightsModel> getAllFlights();

        void updateFlights(FlightsModel flight);

        void deleteFlights(int id);
    }

}
