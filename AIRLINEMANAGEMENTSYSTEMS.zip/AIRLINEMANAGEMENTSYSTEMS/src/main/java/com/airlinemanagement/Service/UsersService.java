package com.airlinemanagement.Service;
import com.airlinemanagement.Model.UsersModel;
import java.util.List;

public class UsersService {
    public interface UserService {

        void addUser(UsersModel user);

        UsersModel getUserById(int id);

        List<UsersModel> getAllUsers();

        void updateUser(UsersModel user);

        void deleteUser(int id);

        UsersModel login(String username, String password);
    }
}
