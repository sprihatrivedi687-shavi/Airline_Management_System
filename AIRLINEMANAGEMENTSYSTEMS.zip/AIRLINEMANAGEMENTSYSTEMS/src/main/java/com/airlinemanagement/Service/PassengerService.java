package com.airlinemanagement.Service;
import com.airlinemanagement.Model.PassengerModel;
import java.util.List;
public abstract class PassengerService {
    public abstract PassengerModel getPassengerById(int id);

    public interface PassengersService {

        void addPassenger(PassengerModel passenger);

        PassengerModel getPassengerById(int id);

        List<PassengerModel> getAllPassengers();

        void updatePassenger(PassengerModel passenger);

        void deletePassenger(int id);
    }
}
