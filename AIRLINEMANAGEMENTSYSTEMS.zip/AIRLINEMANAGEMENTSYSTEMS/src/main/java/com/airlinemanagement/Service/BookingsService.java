package com.airlinemanagement.Service;
import com.airlinemanagement.Model.BookingsModel;
import java.util.List;
public class BookingsService {
    public static interface BookingService {

        void addBooking(BookingsModel booking);

        BookingsModel getBookingById(int id);

        List<BookingsModel> getAllBookings();

        void updateBooking(BookingsModel booking);

        void deleteBooking(int id);
    }
}
