package com.airlinemanagement.Service;
import com.airlinemanagement.Model.PaymentsModel;
import java.util.List;
public class PaymentService {
    public interface PaymentsService {

        void addPayment(PaymentsModel payment);

        PaymentsModel getPaymentById(int id);

        List<PaymentsModel> getAllPayments();

        void updatePayment(PaymentsModel payment);

        void deletePayment(int id);
    }
}
