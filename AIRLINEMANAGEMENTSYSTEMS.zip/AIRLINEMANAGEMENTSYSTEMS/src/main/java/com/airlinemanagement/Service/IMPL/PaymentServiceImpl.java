package com.airlinemanagement.Service.IMPL;

import com.airlinemanagement.DAO.PaymentsDAO.PaymentDao;
import com.airlinemanagement.DAO.Impl.PaymentsDAOImpl;
import com.airlinemanagement.Model.PaymentsModel;
import com.airlinemanagement.Service.PaymentService.PaymentsService;

import java.util.List;

public class PaymentServiceImpl {
}
